import UIKit

protocol RideOn {
    func sitsOnMowerToCutGrass()
}

class Mower {
    
    func startEngine() {
        print("Mower engine starts")
    }
    
    func cutGrass() {
        print("Mower cuts the grass")
    }
}

class RideOnMower: Mower, RideOn {
    func sitsOnMowerToCutGrass() {
        print("Sits on Lawn Mower")
    }
    
    
}

var myMower = Mower()
var myRideOn = RideOnMower()

myMower.startEngine()
myMower.cutGrass()

myRideOn.sitsOnMowerToCutGrass()
myRideOn.startEngine()
myRideOn.cutGrass()



