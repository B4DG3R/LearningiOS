import UIKit


/*
 This Playground is all about Dictionaries
 */

/*
 Dictionaries are very similar to Arrays, but where Arrays are lists of any type of
 data, integers, strings of a list of both.  Dictionaries have a data element and
 each element has a Key.
 */

// This is a dictionary, the Left side is the Key and the Right side is the element
var dict = ["1":"One", "Two": "Two"]

// Keys can also be integers
var newDict = [1: "one", 2: "two", 3: "three"]

// This will add element four with key 4 at the end of the dictionary
newDict[4] = "four"

print(newDict)

// You can change a value
newDict[4] = "five"

print(newDict)

// You can infer the type of a dictionary.  This will make a dictionary with Strings as both
// Keys and elements
var stringDict: [String: String]
var IntDict: [Int: Int]

// You can count them
newDict.count

// You can check if its empty
newDict.isEmpty




