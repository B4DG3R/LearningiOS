import UIKit

var string = "This is a string, but could have been an integer"

string = "I can change this string"

let constantString = "This string is a let constant and cannot be changed"

// Remove the comment mark below to see the constant cannot be changed
// constantString = "I can't change this"

// This is called 'Type Annotation'.
var gotToBeString: String = "This is a string, and could only be a string due to the type annotation"

// You can also use type annotation like this.  You can declare its type without giving it a value.  the : means 'of type.
// so its a variable called typeAnno of type string.
var typeAnno: String

typeAnno = "You can now give it a value"

// This is a multiline string.  To end the string the last 3 """ must be on a new line.
var multilineString = """
                        You can also make strings
                        run over more than one line
                        by adding 3 quotation marks
                        at the top and bottom.
                    """
                    

// You can also use Type Annotation on more than one variable at once.  Separate each variable name by a , .
var one, two, three: Int

var firstName = "Matt"
var lastName = "Hollyhead"

// You can add two variable strings together, this is called concatenating strings
var fullName = firstName + lastName

// You can also add spaces
fullName = firstName + " " + lastName

// This is called string interpolation, you use a string and place variables inside \() to forma
fullName = "You can also add names like this - \(firstName) \(lastName)"

// This is an integer.  Integers a whole numbers whithout a decimal place.
var integer: Int = 7

// This ia a Float.  A Float is a fractional value or number with a decimal place.  A variable of type Float can hold a 32 bit value.
var float: Float = 7.0

// This ia a Double.  A Double is a fractional value or number with a decimal place.  A variable of type Double can hold a 64 bit value.
var double: Double = 7.0

// There are times for using both but mostly a Double is preferred to Float.

// You can add variables with numerical values.
one = 1
two = 2
three = 3

// You can add variables this way
var newNumber = one + two + three
// or you can multiply
newNumber = two * three

// Dont forget than an integer can only return a whole number.  Not a decimal value
newNumber = three / two

// You can also add like this
newNumber = two + 3

// Uncomment below to show that you can't mix number variables of different types.
// var cantDoThis = integer / Double

// But you can do this and a double is infered from the calculation.
var anotherNumber = 3 + double
var newDouble = 7.5123
var anotherNewNumber = 3 + newDouble

// You can pad out zeros with undescores for readablilty
let oneMillion = 1_000_000
let justOverOneMillion = 1_000_000.000_000_1

// This is a print statement.  You can print the content of any variable to the console below.
print("You can also print this to the console below - typeAnno holds the string value: \(typeAnno)")

// You can also add multiple separate items to a single line seperated by a semicolon.
var cat = "I am a cat"; print(cat)

// You can add as many as you like, you can print multiple values, each separated by a comma.
var dog = "I am a dog"; var mouse = "I am a mouse"; var house = "I am a house"; print(dog, mouse, house)



