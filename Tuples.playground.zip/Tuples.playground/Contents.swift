import UIKit

// This Playground is about Tuples

/*
 Tuples are groups of multiple values.  They can be of the same type of different type.  They are ok for simple types of data.
 */

// This tuple takes elements of type Int and type String
var tuple = (1, 2, "Three")

var newTuple = (01234, "Is my number")

// You can decompose the tuple elements into variables and constants
let (myNumber, description) = newTuple

print("my number is \(myNumber)")
