import UIKit

// This ia a comment

// You create a comment by adding // at the start of the comment ans swift ignores it.

// Like this
var comment = "See ^"

var endOfLineComment = "Swift will ignore comment" // At the end of the line.

/*
 This is a multi line comment
 I can write what ever I want in here
 and Swift will ingnore it.
 */
