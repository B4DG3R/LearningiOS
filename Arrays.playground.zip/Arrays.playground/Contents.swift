import UIKit

var one = 1
var two = 2
var three = 3

// An array in Swift looks like this
var array = [one, two, three]

// you can change the order
array = [three, two, one]

// You can remove the first item
array.removeFirst()
print(array)

// You can remove the last item
array.removeLast()
print(array)

// You can remove every item
array.removeAll()
print(array)

// You can declare an array using type annotation so that array can only take integer values
var newArray: [Int] = [1,2,3]

var stringArray: [String] = ["This", "Array", "Only", "Takes", "Strings"]

// This is an empty array of type Int
var wasEmpty: [Int] = []

// You can also declare an empty array like this, this is also an empty array of type Int
var alsoEmpty = [Int]()

// This appends 5 and then 6 to the array
wasEmpty.append(5)
wasEmpty.append(6)

print(wasEmpty)

// This will create an Array with 5 5's in
var anotherArray = Array(repeating: 5, count: 5)

print(anotherArray)

// This will add the two arrays together
var addedArray = wasEmpty + anotherArray

print(addedArray)

// Acceses the first element of the array
addedArray[0]

// This will change the first element of the array to 1 and so on...
addedArray[0] = 1
addedArray[1] = 2
addedArray[2] = 3

print(addedArray)

// This adds Int 4 at position 3 of the array as an addition
addedArray.insert(4, at: 3)

print(addedArray)

// This will count the elements in the array
addedArray.count






