import UIKit

// This is an array of integers
var array = [1,2,3,4,5]

// This is a function that takes an integer adds 1.
// It takes an integer as an input value and then it returns an integer as an output value.
func addOne(n1: Int) -> Int {
    let number = n1 + 1
    
    return number
}
//  This is how the map function looks with a function at the end
array.map(addOne)

// This is how the map funciton looks using a closure, you dont even need the function above to you can completley remove it.
array.map{$0 + 1}
print(array.map({$0 + 1}))


func add(n1: Int, n2: Int) -> Int {
    return n1 + n2
}

func calculator (n1: Int, n2: Int, operation: ((Int, Int) -> Int)) -> Int {
    return operation(n1, n2)
}

let calculation = calculator(n1: 1, n2: 2, operation: {$0 + $1})

print(calculation)




