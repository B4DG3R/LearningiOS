import UIKit

// This Playground is all about Loops.

/*
 There are two types of loops in Swift.  for loops and while loops.
 
 for loops iterate through an array of data or over a specified range.
 
 while loops are conditional and loop until the condition is met
 */

var array = [1,2,3,4,5]

// This for loop will iterate through the array and print each item as it looks at it.
for item in array {
    print(item)
}

var newArray: [Int] = []

// You can append the items of the array to a new array
for item in array {
    newArray.append(item)
}

// Removes all items in the array
newArray.removeAll()

// You can modify the items before adding them to the new array
for items in array {
    newArray.append(items + 1)
}

print(newArray)

// This iterates through any specified range of numbers
for index in (0...5) {
    print("Index is \(index)")
}

// It can be any range of numbers
for index in (5...10) {
    print("Index is \(index)")
}

var counter = 0

// While loops should only be used when you know for an absolute fact that the condition will be met, otherwise the loop will literally loop forever.

// While counter is less than 5 the loop will keep looping
// each time we add 1 to counter, whenm counter is no longer less than 5 it stops
while counter < 5 {
    print("The counter is \(counter)")
    counter += 1
}




